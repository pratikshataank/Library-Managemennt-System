﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class IssueBook : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        public IssueBook()
        {
            InitializeComponent();
            con = new SqlConnection("server=BLT203\\SQLEXPRESS;DataBase=LIBRARY;Integrated Security=true");

        }

        private void issue_Click(object sender, EventArgs e)
        {
            int uid = Convert.ToInt32( UserID.Text);
            string username = UserName.Text;
            string usertype = UserType.Text;
            int bookid = Convert.ToInt32(BookId.Text);
            DateTime issue = Convert.ToDateTime(IssueDate.Text);

            try
            {
                con.Open();
                string query = "insert into  issue_details(U_id,Username,User_type,Book_id,Issue_date) values('" + uid + "','" + username + "','" + usertype + "'," +
                     "'" + bookid + "','" + issue + "')";
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("inserted");
            }
                
       

            
           catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex);
            }

            finally
            {
                con.Close();
            }




        }

        private void UserID_TextChanged(object sender, EventArgs e)
        {
            con.Open();
            string qur = "select * from Registered_user where  U_id="+UserID.Text;
            cmd = new SqlCommand(qur,con);
            dr=cmd.ExecuteReader();

            while (dr.Read())
            {
                UserName.Text = dr[1].ToString();
                UserType.Text = dr[2].ToString();
            }

            con.Close();
        }
    }
}
