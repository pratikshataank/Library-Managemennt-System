﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class Visitor : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        public Visitor()
        {
            InitializeComponent();
            con = new SqlConnection("server=BLT203\\SQLEXPRESS;DataBase=LIBRARY;Integrated Security=true");
        }

        private void IssueDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void V_issue_Click(object sender, EventArgs e)
        {
           
            string Vusername = V_UserName.Text;
            string Vusertype = V_UserType.Text;
            int bookid = Convert.ToInt32(V_BookId.Text);
            string contact = V_ContactNo.Text;
            DateTime issue = Convert.ToDateTime(V_IssueDate.Text);
            try
            {
                con.Open();
                string query = "insert into  Visitor_issuedetail(visitor_name,usertype,Book_id,Contact_NO,issue_date) values('" + Vusername + "','" + Vusertype + "','" + bookid + "'," +
                     "'" + contact + "','" + issue + "')";
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("inserted");
            }
               
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex);
            }

            finally
            {
                con.Close();
            }


        }

        private void vid_TextChanged(object sender, EventArgs e)
        {
            con.Open();
            string qur = "select * from Visitor_issuedetail  where  V_id=" + vid.Text;
            cmd = new SqlCommand(qur, con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                V_UserName.Text = dr[1].ToString();
                V_BookId.Text = dr[2].ToString();
            }
            con.Close();
        }

        /*  private void label2_Click(object sender, EventArgs e)
          {

          }*/
    }
}
