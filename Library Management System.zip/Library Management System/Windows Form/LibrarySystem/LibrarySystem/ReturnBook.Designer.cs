﻿namespace LibrarySystem
{
    partial class ReturnBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Return = new System.Windows.Forms.Button();
            this.UserName = new System.Windows.Forms.TextBox();
            this.ActualDate = new System.Windows.Forms.TextBox();
            this.BookId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.member = new System.Windows.Forms.RadioButton();
            this.visitor = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.u_id = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Return Book";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "User Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-1, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Actual Returning Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(30, 282);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Book Id:";
            // 
            // Return
            // 
            this.Return.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Return.Location = new System.Drawing.Point(99, 322);
            this.Return.Name = "Return";
            this.Return.Size = new System.Drawing.Size(97, 25);
            this.Return.TabIndex = 4;
            this.Return.Text = "Return";
            this.Return.UseVisualStyleBackColor = true;
            this.Return.Click += new System.EventHandler(this.Return_Click);
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(164, 172);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(100, 20);
            this.UserName.TabIndex = 5;
            // 
            // ActualDate
            // 
            this.ActualDate.Location = new System.Drawing.Point(164, 222);
            this.ActualDate.Name = "ActualDate";
            this.ActualDate.Size = new System.Drawing.Size(100, 20);
            this.ActualDate.TabIndex = 6;
            // 
            // BookId
            // 
            this.BookId.Location = new System.Drawing.Point(163, 278);
            this.BookId.Name = "BookId";
            this.BookId.Size = new System.Drawing.Size(100, 20);
            this.BookId.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(30, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Select:";
            // 
            // member
            // 
            this.member.AutoSize = true;
            this.member.Location = new System.Drawing.Point(118, 65);
            this.member.Name = "member";
            this.member.Size = new System.Drawing.Size(63, 17);
            this.member.TabIndex = 9;
            this.member.TabStop = true;
            this.member.Text = "Member";
            this.member.UseVisualStyleBackColor = true;
            // 
            // visitor
            // 
            this.visitor.AutoSize = true;
            this.visitor.Location = new System.Drawing.Point(201, 63);
            this.visitor.Name = "visitor";
            this.visitor.Size = new System.Drawing.Size(52, 17);
            this.visitor.TabIndex = 10;
            this.visitor.TabStop = true;
            this.visitor.Text = "visitor";
            this.visitor.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(51, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "User ID:";
            // 
            // u_id
            // 
            this.u_id.Location = new System.Drawing.Point(164, 121);
            this.u_id.Name = "u_id";
            this.u_id.Size = new System.Drawing.Size(100, 20);
            this.u_id.TabIndex = 12;
            this.u_id.TextChanged += new System.EventHandler(this.u_id_TextChanged);
            // 
            // ReturnBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(366, 359);
            this.Controls.Add(this.u_id);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.visitor);
            this.Controls.Add(this.member);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.BookId);
            this.Controls.Add(this.ActualDate);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.Return);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ReturnBook";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReturnUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Return;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.TextBox ActualDate;
        private System.Windows.Forms.TextBox BookId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton member;
        private System.Windows.Forms.RadioButton visitor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox u_id;
    }
}