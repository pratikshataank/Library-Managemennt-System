﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class AddBook : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;

        public AddBook()
        {
            InitializeComponent();
            con = new SqlConnection("server=BLT203\\SQLEXPRESS;DataBase=LIBRARY;Integrated Security=true");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            string bname=BName.Text;
            string bookcat=BookCat.Items[BookCat.SelectedIndex].ToString();
            string type= Type.Items[Type.SelectedIndex].ToString(); ;
            int totalbook = Convert.ToInt32(TotalBook.Text);

            try
            {
                con.Open();
                string query = "insert into Book values('" + bname + "','" + bookcat + "','" + type + "','" + totalbook + "')";
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("inserted");
            }

            catch
            {
                MessageBox.Show("Not Inserted");
            }

            finally
            {
                con.Close();
            }
           
         

        }

        private void AddBook_Load(object sender, EventArgs e)
        {
            con.Open();
            string que1 = "select Book_cat from category";
            cmd = new SqlCommand(que1, con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                BookCat.Items.Add(dr[0]);

            }
            con.Close();
            con.Open();
            string que2 = "select Book_type from book_type";
            cmd = new SqlCommand(que2, con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Type.Items.Add(dr[0]);

            }
            con.Close();

        }
    }
}
