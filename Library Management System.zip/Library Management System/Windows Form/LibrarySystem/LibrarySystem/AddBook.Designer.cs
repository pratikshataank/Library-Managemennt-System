﻿namespace LibrarySystem
{
    partial class AddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Book = new System.Windows.Forms.Label();
            this.B_Name = new System.Windows.Forms.Label();
            this.BName = new System.Windows.Forms.TextBox();
            this.BCat = new System.Windows.Forms.Label();
            this.BookCat = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Type = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TotalBook = new System.Windows.Forms.TextBox();
            this.Submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Book
            // 
            this.Book.AutoSize = true;
            this.Book.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Book.Location = new System.Drawing.Point(88, 25);
            this.Book.Name = "Book";
            this.Book.Size = new System.Drawing.Size(87, 20);
            this.Book.TabIndex = 0;
            this.Book.Text = "Add Book";
            // 
            // B_Name
            // 
            this.B_Name.AutoSize = true;
            this.B_Name.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_Name.Location = new System.Drawing.Point(32, 82);
            this.B_Name.Name = "B_Name";
            this.B_Name.Size = new System.Drawing.Size(86, 16);
            this.B_Name.TabIndex = 1;
            this.B_Name.Text = "Book Name:";
            // 
            // BName
            // 
            this.BName.Location = new System.Drawing.Point(143, 81);
            this.BName.Name = "BName";
            this.BName.Size = new System.Drawing.Size(100, 20);
            this.BName.TabIndex = 2;
            // 
            // BCat
            // 
            this.BCat.AutoSize = true;
            this.BCat.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BCat.Location = new System.Drawing.Point(32, 129);
            this.BCat.Name = "BCat";
            this.BCat.Size = new System.Drawing.Size(74, 16);
            this.BCat.TabIndex = 3;
            this.BCat.Text = "Category:";
            // 
            // BookCat
            // 
            this.BookCat.FormattingEnabled = true;
            this.BookCat.Location = new System.Drawing.Point(143, 124);
            this.BookCat.Name = "BookCat";
            this.BookCat.Size = new System.Drawing.Size(100, 21);
            this.BookCat.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Type:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Type
            // 
            this.Type.FormattingEnabled = true;
            this.Type.Location = new System.Drawing.Point(143, 174);
            this.Type.Name = "Type";
            this.Type.Size = new System.Drawing.Size(100, 21);
            this.Type.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(41, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Total Book:";
            // 
            // TotalBook
            // 
            this.TotalBook.Location = new System.Drawing.Point(143, 222);
            this.TotalBook.Name = "TotalBook";
            this.TotalBook.Size = new System.Drawing.Size(100, 20);
            this.TotalBook.TabIndex = 8;
            // 
            // Submit
            // 
            this.Submit.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submit.Location = new System.Drawing.Point(92, 276);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(75, 23);
            this.Submit.TabIndex = 9;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // AddBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(291, 311);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.TotalBook);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Type);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BookCat);
            this.Controls.Add(this.BCat);
            this.Controls.Add(this.BName);
            this.Controls.Add(this.B_Name);
            this.Controls.Add(this.Book);
            this.Name = "AddBook";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddBook";
            this.Load += new System.EventHandler(this.AddBook_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Book;
        private System.Windows.Forms.Label B_Name;
        private System.Windows.Forms.TextBox BName;
        private System.Windows.Forms.Label BCat;
        private System.Windows.Forms.ComboBox BookCat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Type;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TotalBook;
        private System.Windows.Forms.Button Submit;
    }
}