﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class AddUser : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;

        public AddUser()
        {
            InitializeComponent();
            con = new SqlConnection("server=BLT203\\SQLEXPRESS;DataBase=LIBRARY;Integrated Security=true");
        }

        

        private void Submit_Click(object sender, EventArgs e)
        {
            string name = UName.Text;
            string type  = UType.Text;
            string dpst = Deposite.Text ;
            string contact = ContactNo.Text;

           
                con.Open();
                string query = "insert into  Registered_user values('" + name + "','" + type + "','" + dpst + "','" + contact + "')";
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("inserted");
                con.Close();
            

          /*  catch
            {
                MessageBox.Show("Not Inserted");
            }*/

          


        }

        private void AddUser_Load(object sender, EventArgs e)
        {

        }
    }
}
