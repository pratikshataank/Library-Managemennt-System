﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class ReturnBook : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;

        string select;
        DateTime Returndate;
        DateTime actualdate;
        public ReturnBook()
        {
            InitializeComponent();
            con = new SqlConnection("server=BLT203\\SQLEXPRESS;DataBase=LIBRARY;Integrated Security=true");


        }

        private void u_id_TextChanged(object sender, EventArgs e)
        {
            if (visitor.Checked == true)
            {
                select = visitor.Text;
                con.Open();
                string qur = "select * from visitor_issuedetail where  V_id='" + u_id.Text + "'";
                cmd = new SqlCommand(qur, con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    BookId.Text = dr[2].ToString();
                    UserName.Text = dr[1].ToString();
                }



                con.Close();
            }

            else if (member.Checked == true)
            {
                select = member.Text;
                con.Open();
                string qur = "select * from issue_details where  U_id='" + u_id.Text + "'";
                cmd = new SqlCommand(qur, con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    UserName.Text = dr[2].ToString();
                    BookId.Text = dr[0].ToString();

                }
                con.Close();
            }

            else
            {
                MessageBox.Show("select any");

            }
        }

        private void Return_Click(object sender, EventArgs e)
        {
            actualdate = Convert.ToDateTime(ActualDate.Text);




            if (select == "Member")
            {

                con.Open();

                string que = "select Return_date from issue_details where U_id='" + u_id.Text + "'";
                cmd = new SqlCommand(que, con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Returndate = Convert.ToDateTime(dr[0].ToString());

                }
                MessageBox.Show(Returndate.ToString());

                con.Close();
                TimeSpan val = actualdate.Subtract(Returndate);
                MessageBox.Show(val.ToString());

                int delay = (int)(val.TotalDays);
                int penalty = delay * 15;
                MessageBox.Show(penalty.ToString());
                
                //updation code
                con.Open();
                string query="update issue_details set Actual_returnDate='"+ actualdate + "', No_of_delay='"+ delay + "',Applicable_penalty='"+penalty+"' where U_id='"+u_id.Text+"' ";
                cmd = new SqlCommand(query,con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated");

                con.Close();
            }
        
            else if (select == "visitor")
            {

                con.Open();

                string que = "select return_date from visitor_issuedetail where V_id='" + u_id.Text + "'";
                cmd = new SqlCommand(que, con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Returndate = Convert.ToDateTime(dr[0].ToString());

                }
                MessageBox.Show(Returndate.ToString());

                con.Close();
                TimeSpan val = actualdate.Subtract(Returndate); //minus two dates
                MessageBox.Show(val.ToString());
               
                int delay = (int)(val.TotalDays);
                int penalty = delay * 20;
                MessageBox.Show(penalty.ToString());

                //updation code
                con.Open();
                string query = "update visitor_issuedetail set ActualReturn_date='" + actualdate + "', No_of_delay='" + delay + "',Applicable_penalty='" + penalty + "' where V_id='" + u_id.Text + "' ";
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated");

                con.Close();






            }
        }

    }

}
