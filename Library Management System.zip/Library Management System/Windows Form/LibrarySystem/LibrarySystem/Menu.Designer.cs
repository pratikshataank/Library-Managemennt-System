﻿namespace LibrarySystem
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddBook = new System.Windows.Forms.Button();
            this.AddUser = new System.Windows.Forms.Button();
            this.ViewBook = new System.Windows.Forms.Button();
            this.IssueBook = new System.Windows.Forms.Button();
            this.ReturnBook = new System.Windows.Forms.Button();
            this.Logout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AddBook
            // 
            this.AddBook.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddBook.Location = new System.Drawing.Point(69, 31);
            this.AddBook.Name = "AddBook";
            this.AddBook.Size = new System.Drawing.Size(137, 40);
            this.AddBook.TabIndex = 0;
            this.AddBook.Text = "Add Book";
            this.AddBook.UseVisualStyleBackColor = true;
            this.AddBook.Click += new System.EventHandler(this.AddBook_Click);
            // 
            // AddUser
            // 
            this.AddUser.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddUser.Location = new System.Drawing.Point(69, 94);
            this.AddUser.Name = "AddUser";
            this.AddUser.Size = new System.Drawing.Size(137, 39);
            this.AddUser.TabIndex = 1;
            this.AddUser.Text = "Add User";
            this.AddUser.UseVisualStyleBackColor = true;
            this.AddUser.Click += new System.EventHandler(this.AddUser_Click);
            // 
            // ViewBook
            // 
            this.ViewBook.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewBook.Location = new System.Drawing.Point(69, 161);
            this.ViewBook.Name = "ViewBook";
            this.ViewBook.Size = new System.Drawing.Size(137, 36);
            this.ViewBook.TabIndex = 2;
            this.ViewBook.Text = "View Book";
            this.ViewBook.UseVisualStyleBackColor = true;
            // 
            // IssueBook
            // 
            this.IssueBook.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IssueBook.Location = new System.Drawing.Point(69, 218);
            this.IssueBook.Name = "IssueBook";
            this.IssueBook.Size = new System.Drawing.Size(137, 36);
            this.IssueBook.TabIndex = 3;
            this.IssueBook.Text = "Issue Book";
            this.IssueBook.UseVisualStyleBackColor = true;
            this.IssueBook.Click += new System.EventHandler(this.IssueBook_Click);
            // 
            // ReturnBook
            // 
            this.ReturnBook.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnBook.Location = new System.Drawing.Point(69, 281);
            this.ReturnBook.Name = "ReturnBook";
            this.ReturnBook.Size = new System.Drawing.Size(137, 40);
            this.ReturnBook.TabIndex = 4;
            this.ReturnBook.Text = "Return Book";
            this.ReturnBook.UseVisualStyleBackColor = true;
            this.ReturnBook.Click += new System.EventHandler(this.ReturnBook_Click);
            // 
            // Logout
            // 
            this.Logout.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logout.Location = new System.Drawing.Point(69, 349);
            this.Logout.Name = "Logout";
            this.Logout.Size = new System.Drawing.Size(137, 32);
            this.Logout.TabIndex = 5;
            this.Logout.Text = "Logout";
            this.Logout.UseVisualStyleBackColor = true;
            this.Logout.Click += new System.EventHandler(this.Logout_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(300, 393);
            this.Controls.Add(this.Logout);
            this.Controls.Add(this.ReturnBook);
            this.Controls.Add(this.IssueBook);
            this.Controls.Add(this.ViewBook);
            this.Controls.Add(this.AddUser);
            this.Controls.Add(this.AddBook);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AddBook;
        private System.Windows.Forms.Button AddUser;
        private System.Windows.Forms.Button ViewBook;
        private System.Windows.Forms.Button IssueBook;
        private System.Windows.Forms.Button ReturnBook;
        private System.Windows.Forms.Button Logout;
    }
}