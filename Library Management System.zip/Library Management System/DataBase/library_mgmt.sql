create DATABASE LIBRARY
ON PRIMARY
(
NAME='LIB_SYSTEM',
FILENAME='D:\sql_logs\Library_mg_log\lib_system.mdf',
SIZE=3MB,
MAXSIZE=30MB,
FILEGROWTH=2%)

LOG ON
(
NAME= 'LIB_TRANS',
FILENAME ='D:\sql_logs\Library_mg_log\lib_trans.ldf',
SIZE=3MB,
MAXSIZE=30MB,
FILEGROWTH=2%);

use LIBRARY;
create table Book(Book_id int identity(100,1) primary key,Book_name varchar(50),Book_cat varchar(30) constraint fb_cat foreign key references  category(Book_cat) on delete cascade,Book_type varchar(30) constraint fb_type foreign key references book_type(Book_type)on delete cascade,total_copy int);
create table Registered_user(U_id int identity(10,1) primary key,Username varchar(30),User_type varchar(30),Deposite int,Contact_No int);

create table issue_details(Book_id int constraint fk_bid foreign key references  Book(Book_id) on delete cascade,U_id int constraint fk_uid foreign key references  Registered_user(U_id) on delete cascade, Username varchar(20) primary key,User_type varchar(20),Issue_date int,Return_date int,
Actual_ReturnDate int, No_of_delay int,Applicable_penalty int);


create table category(Book_cat varchar(30) primary key);

create table book_type(Book_type varchar(30) primary key);
drop table issue_details;
drop table Registered_user;
drop table Book;
create table visitor_issuedetail(V_id int identity(100,1) primary key, visitor_name varchar(30),
Book_id int constraint fk_Bd foreign key references  Book(Book_id) on delete cascade, 
Contact_NO varchar(20),issue_date datetime,return_date datetime,ActualReturn_date datetime,
 No_of_delay int,Applicable_penalty int);

insert into category values('Science');
select * from category;
insert into category values('Computer Book');
insert into category values('Finance Book');



insert into book_type values('Text Book'),
('Magzines'),
('Manuals');
select * from book_type;

select * from Book;

delete from Book;

alter table Registered_user alter column Contact_No varchar(12);
select * from Registered_user;

alter table issue_details alter column Actual_ReturnDate datetime;

create trigger registered_trigger on issue_details
after insert

as begin

update issue_details
set Return_date=dateadd(day,11,Issue_date)

end
insert into issue_details(Book_id,U_id,Username,User_type,Issue_date) values(109,10,'pratiksha','Registered','2020-2-10');
select * from issue_details;

create trigger visitor_trigger on visitor_issuedetail
after insert

as begin

update visitor_issuedetail
set Return_date=dateadd(day,11,Issue_date)

end

select * from visitor_issuedetail;

alter table visitor_issuedetail add usertype varchar(20);

select * from category;

select * from issue_details;