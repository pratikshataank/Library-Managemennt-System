﻿namespace LibrarySystem
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Admin = new System.Windows.Forms.Label();
            this.Name = new System.Windows.Forms.Label();
            this.Admin_Name = new System.Windows.Forms.TextBox();
            this.Admin_Pass = new System.Windows.Forms.TextBox();
            this.A_Pass = new System.Windows.Forms.Label();
            this.LogIn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Admin
            // 
            this.Admin.AutoSize = true;
            this.Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Admin.Location = new System.Drawing.Point(73, 18);
            this.Admin.Name = "Admin";
            this.Admin.Size = new System.Drawing.Size(108, 20);
            this.Admin.TabIndex = 0;
            this.Admin.Text = "Admin Login";
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name.Location = new System.Drawing.Point(33, 72);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(48, 16);
            this.Name.TabIndex = 1;
            this.Name.Text = "Name:";
            // 
            // Admin_Name
            // 
            this.Admin_Name.Location = new System.Drawing.Point(117, 71);
            this.Admin_Name.Name = "Admin_Name";
            this.Admin_Name.Size = new System.Drawing.Size(100, 20);
            this.Admin_Name.TabIndex = 2;
            this.Admin_Name.TextChanged += new System.EventHandler(this.Admin_Name_TextChanged);
            // 
            // Admin_Pass
            // 
            this.Admin_Pass.Location = new System.Drawing.Point(117, 121);
            this.Admin_Pass.Name = "Admin_Pass";
            this.Admin_Pass.Size = new System.Drawing.Size(100, 20);
            this.Admin_Pass.TabIndex = 3;
            // 
            // A_Pass
            // 
            this.A_Pass.AutoSize = true;
            this.A_Pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A_Pass.Location = new System.Drawing.Point(33, 125);
            this.A_Pass.Name = "A_Pass";
            this.A_Pass.Size = new System.Drawing.Size(68, 16);
            this.A_Pass.TabIndex = 4;
            this.A_Pass.Text = "Password";
            // 
            // LogIn
            // 
            this.LogIn.Location = new System.Drawing.Point(90, 184);
            this.LogIn.Name = "LogIn";
            this.LogIn.Size = new System.Drawing.Size(75, 23);
            this.LogIn.TabIndex = 5;
            this.LogIn.Text = "LogIn";
            this.LogIn.UseVisualStyleBackColor = true;
            this.LogIn.Click += new System.EventHandler(this.LogIn_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.LogIn);
            this.Controls.Add(this.A_Pass);
            this.Controls.Add(this.Admin_Pass);
            this.Controls.Add(this.Admin_Name);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.Admin);
           // this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Admin;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.TextBox Admin_Name;
        private System.Windows.Forms.TextBox Admin_Pass;
        private System.Windows.Forms.Label A_Pass;
        private System.Windows.Forms.Button LogIn;
    }
}

