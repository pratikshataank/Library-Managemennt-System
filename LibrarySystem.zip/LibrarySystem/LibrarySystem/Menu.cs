﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void AddBook_Click(object sender, EventArgs e)
        {
            AddBook book = new AddBook();
            book.Show();
        }

        private void AddUser_Click(object sender, EventArgs e)
        {
            AddUser user = new AddUser();
            user.Show();
        }

        private void IssueBook_Click(object sender, EventArgs e)
        {
            IssueBook issue = new IssueBook();
            issue.Show();
        }

        private void ReturnBook_Click(object sender, EventArgs e)
        {
            ReturnBook rbook = new ReturnBook();
            rbook.Show();
            
        }
    }
}
